using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace TicTacToe
{
    public class TurnController : MonoBehaviour
    {
        public BlockProperties blockProperties;
        public Text letterText;
        public Button clickBtn;

        public void CheckTrun()
        {
            Debug.Log(" 1 || X Turn" + GameController.instance.isXTurn);
            if (GameController.instance.isXTurn)
            {
                letterText.text = "X";
                Debug.Log(letterText.text);
            }
            else
            {
                letterText.text = "O";
            }
            GameController.instance.isXTurn = !GameController.instance.isXTurn;
            clickBtn.interactable = false;
            GameController.instance.FindWinCondition();
            Debug.Log(" 2 || X Turn" + GameController.instance.isXTurn);
        }
    }
    [System.Serializable]
    public class BlockProperties
    {
        public int rowNum;
        public int columnNum;
    }
}
