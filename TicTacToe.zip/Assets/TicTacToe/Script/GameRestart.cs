using UnityEngine;
using UnityEngine.SceneManagement;

namespace TicTacToe
{
    public class GameRestart : MonoBehaviour
    {
        public void LoadScene(string SecondScene)
        {
            SceneManager.LoadScene(SecondScene);
        }
    }
}