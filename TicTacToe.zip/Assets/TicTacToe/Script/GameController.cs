using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace TicTacToe
{
    public class GameController : MonoBehaviour
    {
        public static GameController instance;
        public bool isXTurn;   // manage Turn
        public GameObject blockPrefab;
        public Transform blockParent;
        public List<TurnController> blocksList = new List<TurnController>();
        [Header("Win")]
        public GameObject winpanel;
        public Text winText;
        private void Awake()
        {
            if (instance == null)
            {
                instance = this;
            }
            CreateGameBoard();
        }
        public void CreateGameBoard()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    TurnController clone = Instantiate(blockPrefab, blockParent).GetComponent<TurnController>();
                    clone.name = i + "," + j;
                    var prop = new BlockProperties();
                    clone.blockProperties = prop;
                    prop.rowNum = i;
                    prop.columnNum = j;
                    blocksList.Add(clone);
                }
            }
        }
        public void CheckRow(int row)  // Check Row Win Condition
        {
            List<TurnController> rowList = new List<TurnController>();

            int CountX = 0;
            int CountO = 0;

            for (int i = 0; i < blocksList.Count; i++)
            {
                if (blocksList[i].blockProperties.rowNum == row)
                {
                    rowList.Add(blocksList[i]);
                }
            }
            for (int i = 0; i < rowList.Count; i++)
            {
                if (rowList[i].letterText.text == "X")
                {
                    CountX++;
                }
                else if (rowList[i].letterText.text == "O")
                {
                    CountO++;
                }
            }
            if (CountO == 3)
            {
                WinnerScreen("O");
            }
            if (CountX == 3)
            {
                WinnerScreen("X");
            }
        }

        public void CheckColumn(int column)  // Check Column Win Condition
        {
            List<TurnController> columnList = new List<TurnController>();

            int CountX = 0;
            int CountO = 0;

            for (int i = 0; i < blocksList.Count; i++)
            {
                if (blocksList[i].blockProperties.columnNum == column)
                {
                    columnList.Add(blocksList[i]);
                }
            }
            for (int i = 0; i < columnList.Count; i++)
            {
                if (columnList[i].letterText.text == "X")
                {
                    CountX++;
                }
                else if (columnList[i].letterText.text == "O")
                {
                    CountO++;
                }
            }
            if (CountO == 3)
            {
                WinnerScreen("O");
            }
            if (CountX == 3)
            {
                WinnerScreen("X");
            }
        }

        public void CheckDiagonal()  // Check Diagonal Win Condition
        {
            List<TurnController> diagonalList = new List<TurnController>();

            int CountX = 0;
            int CountO = 0;

            for (int i = 0; i < blocksList.Count; i++)
            {
                if (blocksList[i].blockProperties.rowNum == blocksList[i].blockProperties.columnNum)
                {
                    diagonalList.Add(blocksList[i]);
                }
            }
            for (int i = 0; i < diagonalList.Count; i++)
            {
                if (diagonalList[i].letterText.text == "X")
                {
                    CountX++;
                }
                else if (diagonalList[i].letterText.text == "O")
                {
                    CountO++;
                }
            }
            if (CountO == 3)
            {
                WinnerScreen("O");
            }
            if (CountX == 3)
            {
                WinnerScreen("X");
            }
        }

        public void CheckAntiDiagonal(int num)  // Check AntiDiagonal Win Condition
        {
            List<TurnController> antiDiagonalList = new List<TurnController>();

            int CountX = 0;
            int CountO = 0;

            for (int i = 0; i < blocksList.Count; i++)
            {
                if (blocksList[i].blockProperties.rowNum + blocksList[i].blockProperties.columnNum == 2)
                {
                    antiDiagonalList.Add(blocksList[i]);
                }
            }
            for (int i = 0; i < antiDiagonalList.Count; i++)
            {
                if (antiDiagonalList[i].letterText.text == "X")
                {
                    CountX++;
                }
                else if (antiDiagonalList[i].letterText.text == "O")
                {
                    CountO++;
                }
            }
            if (CountO == 3)
            {
                WinnerScreen("O");
            }
            if (CountX == 3)
            {
                WinnerScreen("X");
            }
        }
        public void FindWinCondition()
        {
            for (int i = 0; i < 3; i++)
            {
                CheckRow(i);
                CheckColumn(i);
                CheckDiagonal();
                CheckAntiDiagonal(2);
            }
        }

        public void WinnerScreen(string winletter)
        {
            winpanel.SetActive(true);
            winText.text = winletter + " Is Win";
        }
    }
}
